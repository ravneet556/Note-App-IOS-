
import UIKit
import AVFoundation
import CoreData
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)

    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

class DisplayNoteViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, AVAudioPlayerDelegate, UIGestureRecognizerDelegate  {
    var note: Note?

 var audioRecorder : AVAudioRecorder?
 var audioPlayer : AVAudioPlayer?
    @IBOutlet weak var playButton: UIButton!
     @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var subjectTF: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var contentTV: UITextView!
    @IBOutlet weak var titleTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
        playButton.isEnabled = false
        playButton.layer.cornerRadius = 5
        recordButton.layer.cornerRadius = 5
            micSetup()
            let longGesture = UITapGestureRecognizer(target: self, action: #selector(add(longGesture: )))
              longGesture.delegate = self
            imageView.addGestureRecognizer(longGesture)
      
    }
    func micSetup(){
           //session
           try?
               AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayAndRecord)
           try? AVAudioSession.sharedInstance().overrideOutputAudioPort(.speaker)
           try? AVAudioSession.sharedInstance().setActive(true)
           // url for saving
           if let basePath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
               let filepatharray = [basePath, "dasound.m4a"]
               if let audioURL = NSURL.fileURL(withPathComponents: filepatharray) {
                   var settings : [String:Any] = [:]
                   settings[AVFormatIDKey] = Int(kAudioFormatMPEG4AAC)
                   settings[AVSampleRateKey] = 44_100.0
                   settings[AVNumberOfChannelsKey] = 2
                   
                   audioRecorder = try? AVAudioRecorder(url: audioURL, settings: settings)
                   audioRecorder?.prepareToRecord()
               }
           }
       }
       
       
       
       @IBAction func playButtonTapped(_ sender: Any) {
           if let player = audioPlayer {
               if player.isPlaying {
                   // Stop
                   stopPlaying()
               } else {
                   // Start
                   startPlaying()
               }
           } else {
               startPlaying()
           }
       }
       @IBAction func recordButtonTapped(_ sender: Any) {
           if let recorder = audioRecorder {
               if recorder.isRecording {
                   // Stop Recording
                   recorder.stop()
                   recordButton.setTitle("Record", for: .normal)
                   playButton.isEnabled = true
                  
               } else {
                   // Start recording
                   recorder.record()
                   recordButton.setTitle("Stop", for: .normal)
                   playButton.isEnabled = false
                 
               }
           }
       }
       func startPlaying(){
           if let audioURL = audioRecorder?.url {
               audioPlayer = try? AVAudioPlayer(contentsOf: audioURL)
               audioPlayer?.delegate = self
               audioPlayer?.prepareToPlay()
               audioPlayer?.play()
               playButton.setTitle("Stop", for: .normal)
               recordButton.isEnabled = false
              
           
       }
       
       }
       func stopPlaying(){
           audioPlayer?.stop()
           audioPlayer?.currentTime = 0
           playButton.setTitle("Play", for: .normal)
           recordButton.isEnabled = true
       }
       
       func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
           playButton.setTitle("Play", for: .normal)
           recordButton.isEnabled = true
       }
       
    //The method viewWillAppear(_:) is a view controller lifecycle method that is called right before a view is about to appear on the screen.
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if let note = note {
            //
            titleTF.text = note.title?.uppercased()
            contentTV.text = note.content
            subjectTF.text = note.subject
            if  note.images != nil {
                imageView.image = UIImage(data: note.images! as Data)}
        
              }
        else {
      titleTF.text = ""
      contentTV.text = ""
    subjectTF.text = ""
      imageView.image = UIImage(named: "camera1")
  }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else { return }

        switch identifier {
        case "save" where note != nil:
            note?.subject = subjectTF.text ?? ""
            note?.title = titleTF.text ?? ""
            note?.content = contentTV.text ?? ""
            note?.dateandtime = Date()
            if let  data = UIImageJPEGRepresentation(self.imageView.image!, 1.0)
          { note?.images = data as NSData as Data
                               }
            if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
            
            
            if let audioURL = audioRecorder?.url{
                note?.soundData = try? Data(contentsOf: audioURL)
                try? context.save()
                
            }
        
            }


            CoreDataHelper.saveNote()

        case "save" where note == nil:
            let note = CoreDataHelper.newNote()
            note.subject = subjectTF.text ?? ""
            note.title = titleTF.text ?? ""
            note.content = contentTV.text ?? ""
            note.dateandtime = Date()
            if imageView.image != nil {
                if  let  data = UIImageJPEGRepresentation(self.imageView.image!, 1.0) {
                    
                    note.images = data as NSData as Data }
             }
            
                if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
                
                
                if let audioURL = audioRecorder?.url{
                    note.soundData = try? Data(contentsOf: audioURL)
                    try? context.save()
                    
                }
            
                }

            
                
            CoreDataHelper.saveNote()

        case "cancel":
            print("cancel bar button item tapped")

        default:
            print("unexpected segue identifier")
        }
    }
    
    
    
    @objc func add(longGesture : UITapGestureRecognizer){
        print ("hello")
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.allowsEditing = true
        let imagePicker = UIImagePickerController()
               imagePicker.delegate = self
               let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a source", preferredStyle: .actionSheet )
               
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: {(action: UIAlertAction) in imagePicker.sourceType = .camera
                   if UIImagePickerController.isSourceTypeAvailable(.camera){
                   imagePicker.sourceType = .camera
                       self.present(imagePicker, animated: true, completion: nil)}
                   else{
                       print("Camera not available")
                   }
               }))
               
               actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: {(action: UIAlertAction) in imagePicker.sourceType = .photoLibrary
                   self.present(imagePicker, animated: true, completion: nil)
               }))
               
               actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
               self.present(actionSheet, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        imageView.image = image
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
                picker.dismiss(animated: true, completion: nil)
    }
    
}
