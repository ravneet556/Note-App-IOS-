
import UIKit
import MapKit
import Foundation
import CoreLocation
class mapScreen : UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    @IBOutlet weak var myTextView: UITextView!
    
    
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        mapView.showsUserLocation = true
        mapView.delegate = self
    }
    
    @IBOutlet weak var labelAdd: UILabel!
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
    if let newLocation = locations.last {

        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(newLocation) { (placemarks, error) in
            if (error != nil){
                print("error in reverseGeocode")
            }
            if placemarks != nil {
            let placemark = placemarks! as [CLPlacemark]
            if placemark.count>0{
                let placemark = placemarks![0]
                print(placemark.postalCode!)
                print(placemark.locality!)
                print(placemark.administrativeArea!)
                print(placemark.country!)

                self.labelAdd.text = "\(placemark.locality!), \(placemark.administrativeArea!), \(placemark.country!)"
            }
        }
        }
    } }
    
    
    
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
    let zoomArea = MKCoordinateRegion(center: self.mapView.userLocation.coordinate, span: MKCoordinateSpan (latitudeDelta: 0.05, longitudeDelta: 0.05))
        self.mapView.setRegion(zoomArea, animated: true)
    }
    
    func geocode(latitude: Double, longitude: Double, completion: @escaping (CLPlacemark?, Error?) -> ())  {
        CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: latitude, longitude: longitude)) { completion($0?.first, $1) }
    

    geocode(latitude: latitude, longitude: longitude)
    {
        placemark, error in guard let placemark = placemark, error == nil else { return }

        DispatchQueue.main.async {
           
            print("address1:", placemark.thoroughfare ?? "")
            print("address2:", placemark.subThoroughfare ?? "")
            print("city:",     placemark.locality ?? "")
            print("state:",    placemark.administrativeArea ?? "")
            print("zip code:", placemark.postalCode ?? "")
            print("country:",  placemark.country ?? "")
        }
        }
      
    }
}


