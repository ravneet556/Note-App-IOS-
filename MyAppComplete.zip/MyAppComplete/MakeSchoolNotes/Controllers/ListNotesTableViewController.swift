

import UIKit
import CoreData
import AVFoundation
class ListNotesTableViewController: UITableViewController, UISearchBarDelegate, UISearchDisplayDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var searchBar: UISearchBar!
    
     var audioPlayer : AVAudioPlayer?
     override func viewWillAppear(_ animated: Bool) {
         getSounds()
     }
    var notes = [Note]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setCustomBackImage()
        notes = CoreDataHelper.retrieveNotes()
        searchBar.delegate = self
        }
    func getSounds(){
         if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
             if let tempSounds = try? context.fetch(Note.fetchRequest()) as? [Note]{
                 if let theSounds = tempSounds {
                     notes = theSounds
                     tableView.reloadData()
                 }
             }
         }
     }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }
    
    //display the cell's index path (row and section).
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "listNotesTableViewCell", for: indexPath) as! ListNotesTableViewCell
        let note = notes[indexPath.row]
        cell.subLbl.text = note.subject?.uppercased()
        cell.noteTitle.text = note.title?.uppercased()
        cell.noteDate.text = note.dateandtime?.convertToString() ?? "unknown"
        cell.noteDesc.text = note.content
        if note.images != nil{
       
            cell.imageView1.image = UIImage(data: note.images! as Data)
        }
        else {
            cell.imageView1.image = UIImage(named : "camera1")
        }
        
        cell.onTapCellDelegate = {() in
            
            let note = self.notes[indexPath.row]
            if let audioData = note.soundData{
                self.audioPlayer = try? AVAudioPlayer(data: audioData)
                self.audioPlayer?.prepareToPlay()
                self.audioPlayer?.play()
            }
            
        }
        
        return cell
    }

   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else { return }
        switch identifier {
        case "displayNote":
            
                 guard let indexPath = tableView.indexPathForSelectedRow else { return }
                 let note = notes[indexPath.row]
//                 if let audioData = note.soundData{
//                    audioPlayer = try? AVAudioPlayer(data: audioData)
//                    audioPlayer?.prepareToPlay()
//                    audioPlayer?.play()
//                 }
                 let destination = segue.destination as! DisplayNoteViewController
                 destination.note = note
        case "addNote":
            print("create note bar button item tapped")
        default:
            print("unexpected segue identifier")
        }
    }


    
    
    //to delete
 override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
         let noteToDelete = notes[indexPath.row]
         CoreDataHelper.delete(note: noteToDelete)
         notes = CoreDataHelper.retrieveNotes()
     }
 }
    
    
    //to unwind segue
    @IBAction func unwindWithSegue(_ segue: UIStoryboardSegue) {
    notes = CoreDataHelper.retrieveNotes()
    }
    
    func setCustomBackImage(){
          navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
      }
    
    
    
    //SEARCH
    
    func  searchBar(_ searchBar : UISearchBar, textDidChange searchText : String){
        if searchText != "" {
            var predicate : NSPredicate = NSPredicate()
            predicate = NSPredicate(format: "title contains[c] '\(searchText)'")
            var predicate1 : NSPredicate = NSPredicate()
            predicate1 = NSPredicate(format: "content contains[c] '\(searchText)'")
            let compound = NSCompoundPredicate(orPredicateWithSubpredicates: [predicate,predicate1])
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
            fetchRequest.predicate = compound
            do{
                notes = try context.fetch(fetchRequest) as! [NSManagedObject] as! [Note]
            }catch{
                print("Could not get search data")
            }
        }
        tableView.reloadData()
    }
    

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar){
            searchBar.text = ""
        notes = CoreDataHelper.retrieveNotes()
    }
    
    
       
    
    
    
    //SORTING
    
    func sortByDate(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
              let context = appDelegate.persistentContainer.viewContext
              let fetchRequest1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
              let sortDescriptor = NSSortDescriptor(key: "dateandtime", ascending: true)
                fetchRequest1.sortDescriptors = [sortDescriptor]
              do{
                               notes = try context.fetch(fetchRequest1) as! [NSManagedObject] as! [Note]
                           }catch{
                               print("Could not get search data")
                           }
    }
    
    func sortByTitle(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
         let context = appDelegate.persistentContainer.viewContext
         let fetchRequest1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
         let sortDescriptor = NSSortDescriptor(key: "title", ascending: true)
           fetchRequest1.sortDescriptors = [sortDescriptor]
         do{
                          notes = try context.fetch(fetchRequest1) as! [NSManagedObject] as! [Note]
                      }catch{
                          print("Could not get search data")
                      }
        
    }
    func sortBySubject(){
         let appDelegate = UIApplication.shared.delegate as! AppDelegate
          let context = appDelegate.persistentContainer.viewContext
          let fetchRequest1 = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
        let sortDescriptor = NSSortDescriptor(key: "subject", ascending: true)
            fetchRequest1.sortDescriptors = [sortDescriptor]
          do
            {
               notes = try context.fetch(fetchRequest1) as! [NSManagedObject] as! [Note]
                
            }
          catch
          {
            print("Could not get search data")
          }
         
     }
    @IBAction func sorting(_ sender: Any) {
 
        let actionSheet = UIAlertController(title: "Sort By", message: "Select", preferredStyle: .actionSheet )
        actionSheet.addAction(UIAlertAction(title: "Date", style: .default, handler: {(action: UIAlertAction) in self.sortByDate()
       
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Title", style: .default, handler: {(action: UIAlertAction) in self.sortByTitle()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Subject", style: .default, handler: {(action: UIAlertAction) in self.sortBySubject()
               }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
 
         }
    
    

}
