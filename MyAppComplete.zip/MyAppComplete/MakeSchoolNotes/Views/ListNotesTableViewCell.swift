//
//  ListNotesTableViewCell.swift
//  MakeSchoolNotes
//
//  Created by Chris Orcutt on 10/18/15.
//  Copyright © 2015 Make School. All rights reserved.
// 

import UIKit

class ListNotesTableViewCell: UITableViewCell {
    @IBOutlet weak var imageView1: UIImageView!
    
    @IBOutlet weak var audioButton: UIButton!
    @IBOutlet weak var subLbl: UILabel!
    
    @IBOutlet weak var noteTitle: UILabel!
    
    @IBOutlet weak var noteDate: UILabel!
    @IBOutlet weak var noteDesc: UILabel!
    
    var onTapCellDelegate:(()->Void)?
    
    @IBAction func audioButtonAction(_ sender: Any) {
        
        onTapCellDelegate == nil ? print("nil") : onTapCellDelegate!()
        
    }
    
    
}
